import sqlite3


conn = sqlite3.connect('database.db')
c = conn.cursor()

c.execute("SELECT * FROM StudentDb")
data = c.fetchall()
conn.close()

print(str(data))
