import tkinter
from tkinter import *
from tkinter import ttk, messagebox


class UpdateDetails(tkinter.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.geometry('300x300')
        self.title('Update Details Screen')
        Label(self, text="price:").place(x=40, y=75)
        self.entry_price = Entry(self)
        self.entry_price.place(x=125, y=75)
        Label(self, text="years of experience:").place(x=40, y=125)
        self.entry_experience = Entry(self)
        self.entry_experience.place(x=125, y=125)
        self.btn_update = Button(self, text="update", background="pink").place(x=110, y=200)
        self.btn_close = Button(self, text="close", background="red", command=self.close).place(x=110, y=250)


    def update(self):
        if (len(self.entry_price.get()) == 0) and (len(self.entry_experience.get()) == 0):
            messagebox.showerror("error", "please write your new details")
            return


    def close(self):
        self.parent.deiconify()
        self.destroy()

