import tkinter
from tkinter import *
from tkinter import ttk, messagebox


class StudentsList(tkinter.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.geometry('400x400')
        self.title('Students List Screen')
        self.listbox()


    def listbox(self):
        arr = ["students_list"]
        str_insert = ",".join(arr)
        print(str_insert)
        self.parent.parent.parent.client_socket.send(str_insert.encode())
        # data = self.parent.client_socket.recv(1024).decode()
        # print(data)
